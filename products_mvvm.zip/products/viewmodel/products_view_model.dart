import 'package:architecture_pattern_mvvm/products/model/products.dart';
import 'package:architecture_pattern_mvvm/products/model/service/products_repository.dart';
import 'package:flutter/material.dart';

class ProductViewModel with ChangeNotifier {
  final ProductRepository _repository = ProductRepository();
  List<Products> _productArr = [];
  List<Products> get productArr => _productArr;
  bool fetchingData = false;

  Future<void> fetchProducts() async {
    fetchingData = true;
    try {
      _productArr = await _repository.getProducts();
      notifyListeners();
    } catch (e) {
      throw Exception('Failed to load Products in ViewModel : $e');
    }
    fetchingData = false;
  }
}
