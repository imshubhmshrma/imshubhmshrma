import 'package:architecture_pattern_mvvm/products/model/products.dart';
import 'package:architecture_pattern_mvvm/products/view/product_details.dart';
import 'package:architecture_pattern_mvvm/products/viewmodel/products_view_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

class ProductScreen extends StatefulWidget {
  const ProductScreen({super.key});

  @override
  State<ProductScreen> createState() => _ProductScreenState();
}

class _ProductScreenState extends State<ProductScreen> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.lightBlue.shade50,
          title: const Text('Products'),
        ),
        body: Consumer<ProductViewModel>(builder: (context, viewModel, child) {
          if (!viewModel.fetchingData && viewModel.productArr.isEmpty) {
            Provider.of<ProductViewModel>(context, listen: false)
                .fetchProducts();
          }
          if (viewModel.fetchingData) {
            // While data is being fetched
            return const Center(child: LinearProgressIndicator());
          } else {
            // If data is successfully fetched
            List<Products> heroes = viewModel.productArr;
            return Column(
              children: [
                Flexible(
                    child: ListView.builder(
                  itemCount: heroes.length,
                  itemBuilder: (context, index) {
                    return ListTileCard(
                        character: heroes[
                            index]); //ListCard(character: heroes[index]);
                  },
                ))
              ],
            );
          }
        }),
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            Provider.of<ProductViewModel>(context, listen: false)
                .fetchProducts();
          },
          child: const Icon(Icons.refresh),
        ),
      ),
    );
  }
}

//class for List Card
class ListCard extends StatelessWidget {
  const ListCard({super.key, required this.character});

  final Products character;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onTap: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) =>
                      ProductDetailScreen(characterDetail: character)));
        },
        child: Container(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
          child: DecoratedBox(
            decoration: BoxDecoration(
                color: Colors.lightBlue.shade50,
                borderRadius: BorderRadius.circular(16)),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Row(
                children: [
                  Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          FittedBox(
                            fit: BoxFit.scaleDown,
                            child: Text(
                              character.title ?? "",
                              style: const TextStyle(
                                  color: Colors.black,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold),
                              textAlign: TextAlign.start,
                            ),
                          ),
                          Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: FittedBox(
                                fit: BoxFit.scaleDown,
                                child: Text(
                                  character.brand ?? "",
                                  style: const TextStyle(
                                      color: Colors.black,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w400),
                                ),
                              ))
                        ],
                      ))
                ],
              ),
            ),
          ),
        ));
  }
}

class ListTileCard extends StatelessWidget {
  const ListTileCard({super.key, required this.character});

  final Products character;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(6, 10, 6, 10),
      child: DecoratedBox(
        decoration: BoxDecoration(
            color: Colors.lightBlue.shade50,
            borderRadius: BorderRadius.circular(16)),
        child: ListTile(
          title: Text(
            character.title ?? "",
            style: const TextStyle(
                color: Colors.black, fontSize: 20, fontWeight: FontWeight.bold),
            textAlign: TextAlign.start,
          ),
          subtitle: Text(
            'Price : ${character.price} USD',
            style: const TextStyle(
                color: Colors.black, fontSize: 20, fontWeight: FontWeight.bold),
            textAlign: TextAlign.start,
          ),
          trailing: const Icon(Icons.arrow_forward),
          onTap: () {
            // Update the tapped item index
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        ProductDetailScreen(characterDetail: character)));
          },
        ),
      ),
    );
  }
}
