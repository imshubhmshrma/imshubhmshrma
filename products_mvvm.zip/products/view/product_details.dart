import 'package:architecture_pattern_mvvm/products/model/products.dart';
import 'package:flutter/material.dart';

class ProductDetailScreen extends StatelessWidget {
  const ProductDetailScreen({super.key, required this.characterDetail});

  final Products characterDetail;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlue.shade50,
        title: const Text('Products Detail'),
      ),
      body: ListView(
        shrinkWrap: true,
        physics: const ScrollPhysics(),
        children: <Widget>[
          const SizedBox(
            height: 20,
          ),
          SizedBox(
            height: 400,
            width: MediaQuery.of(context).size.width,
            child: ListView.builder(
                scrollDirection: Axis.horizontal,
                shrinkWrap: true,
                itemCount: characterDetail.images?.length ?? 0,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => RouteTwo(
                            image: characterDetail.images?[index] ?? '',
                            name: characterDetail.title ?? '',
                          ),
                        ),
                      );
                    },
                    child: SizedBox(
                      height: 200,
                      width: MediaQuery.of(context).size.width,
                      child: Image.network(
                        characterDetail.images?[index] ?? '',
                        height: MediaQuery.of(context).size.height / 1.8,
                        fit: BoxFit.fill,
                      ),
                    ),
                  );
                }),
          ),
          // Product image

          const SizedBox(
            height: 20,
          ),
          // Image.network(
          //   characterDetail.thumbnail ?? '',
          //   height: MediaQuery.of(context).size.height / 1.8,
          //   fit: BoxFit.fill,
          // ),
          // const SizedBox(
          //   height: 20,
          // ),
          // Product title
          Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 8.0, vertical: 10.0),
            child: Text(
              characterDetail.title ?? '',
              style:
                  const TextStyle(fontWeight: FontWeight.bold, fontSize: 18.0),
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          // Product description
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Text(
              characterDetail.brand ?? '',
            ),
          ),

          // Product price
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              'Price : ${characterDetail.price ?? ''} USD',
              style:
                  const TextStyle(fontSize: 18.0, fontWeight: FontWeight.w500),
            ),
          ),
          const SizedBox(
            height: 30.0,
          ),
        ],
      ),
    );
  }
}

class RouteTwo extends StatelessWidget {
  final String image;
  final String name;

  RouteTwo({Key? key, required this.image, required this.name})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Image ✌️'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            AspectRatio(
              aspectRatio: 1,
              child: SizedBox(
                width: double.infinity,
                child: Image(
                  image: NetworkImage(image),
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.all(20.0),
              child: Center(
                child: Text(
                  name,
                  style: const TextStyle(fontSize: 40),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
