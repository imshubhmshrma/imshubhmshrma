import 'dart:convert';
import 'package:architecture_pattern_mvvm/products/model/products.dart';
import 'package:architecture_pattern_mvvm/products/model/service/product_service.dart';

class ProductRepository {
  final ProductService _productService = ProductService();

  Future<List<Products>> getProducts() async {
    final response = await _productService.fetchProducts();
    if (response.statusCode == 200) {
      //we get JSON response here inside response.body
      final res = jsonDecode(response.body)
          as Map<String, dynamic>; // here I am decoding the JSON
      final prodList = res['products']
          as List; // I am getting product list from the response

      List<Products> productList =
          prodList.map((tagJson) => Products.fromJson(tagJson)).toList();

      return productList;
    } else {
      throw Exception('Failed to load products in repository');
    }
  }
}
