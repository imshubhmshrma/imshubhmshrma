import 'dart:convert';

import 'package:architecture_pattern_mvvm/products/model/service/apis/app_exception.dart';
import 'package:http/http.dart' as http;

class ProductService {
  final _apiURL = 'https://dummyjson.com/products';

  Future<dynamic> getResponse() async {
    try {
      final response = await http.get(Uri.parse(_apiURL));
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      }
    } catch (e) {
      throw FetchDataException(
          'Getting error while fetching Products ${e.toString()}');
    }
  }

  Future<http.Response> fetchProducts() async {
    return await http.get(Uri.parse(_apiURL));
  }
}
